@extends('layout/fahri');

@section("Judul", 'Daftar Mahasiswa')
@section('container')
<div class="container">
    Muhamad Fachri!

</div>
@endsection
