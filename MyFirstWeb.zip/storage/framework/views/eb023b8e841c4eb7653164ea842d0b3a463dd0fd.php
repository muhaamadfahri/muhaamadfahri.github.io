;

<?php $__env->startSection("Judul", 'Daftar Mahasiswa'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
    Muhamad Fachri!

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/fahri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyFirstWeb\resources\views/index.blade.php ENDPATH**/ ?>