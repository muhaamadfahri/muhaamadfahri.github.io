;

<?php $__env->startSection("Judul", 'About'); ?>
<?php $__env->startSection('container'); ?>
<div class="container">
<div class="row">
<div class="col-10">
    <h1 class="mt-3">Hello, <?php echo e($nama); ?>!</h1>
</div></div></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/fahri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MyFirstWeb\resources\views/About.blade.php ENDPATH**/ ?>